#include<stdio.h>

int main()
{
    int user_id = 222115008;
    int value = 9999;
    int result =  user_id + value;
    
    printf("a = %d\n", result);
    
}